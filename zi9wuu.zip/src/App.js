import "./styles.css";
import ImageUploader from "./Upload";
export default function App() {
  return (
    <div className="App">
      <ImageUploader />
    </div>
  );
}
