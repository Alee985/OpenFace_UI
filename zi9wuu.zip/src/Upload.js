import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import axios from 'axios';

function ImageUploader() {
  const [file, setFile] = useState(null);

  const onDrop = useCallback((acceptedFiles) => {
    console.log("FILE BEFORE LOG", file);
    console.log("ACCEPTED FILES : ",acceptedFiles)
    setFile(URL.createObjectURL(acceptedFiles[0]));
    console.log("FILE AFTER LOG", file);
    
    uploadFile(file) // set the dropped file to state
  }, [file]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });
  
  const uploadFile = async (file) => {
    const formData = new FormData();
    console.log("FILE DETAILS : ", file);
    formData.append('file', file)
    console.log("Formdata printing"+formData);
    try {
        const res = await axios.post(
            'https://alitest.free.beeceptor.com',
            formData,
            {
                headers: {
                'Content-Type':'multipart/form-data'
            }
        }
        );
        console.log(res);
    }
    catch (ex) {
      if(ex.response==='200'){
        console.log(ex.response.data);
      }
    }
};

  return (
    <div>
      <div
        {...getRootProps()}
        style={{
          border: "1px solid #ccc",
          padding: "20px",
          margin: "20px",
          width: "300px",
          height: "200px"
        }}
      >
        <input {...getInputProps()} />
        {isDragActive ? (
          <p>Drop the file here ...</p>
        ) : (
          <p>Drag 'n' drop a file here, or click to select a file</p>
        )}
      </div>
      {file && (
        <img
          src={file}
          alt="Dropped file"
          style={{ width: "300px", height: "200px", objectFit: "cover" }}
        />
      )}{" "}
      {/* display the dropped file in another div */}
    </div>
  );
}

export default ImageUploader;
